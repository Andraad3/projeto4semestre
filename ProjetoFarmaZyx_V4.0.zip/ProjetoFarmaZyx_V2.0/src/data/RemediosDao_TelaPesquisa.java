package data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class RemediosDao_TelaPesquisa {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/remedio","root","");
            
            
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            return false;
        }
    }
    
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    
    public Remedios consultar(String pesquisar){
        Remedios rem = new Remedios();
        try {
            st = conn.prepareStatement("SELECT *FROM remedio WHERE produto LIKE ?");
            st.setString(1, '%' +pesquisar+'%');
            ResultSet rs = st.executeQuery();
             if(rs.next()){
                 rem.setIdProduto(rs.getString("id_produto"));
                 rem.setProduto(rs.getString("produto"));
                 rem.setComposicao(rs.getString("composicao"));
                 rem.setPosologia(rs.getString("posologia"));
                 rem.setOndeAge(rs.getString("onde_age"));
                 rem.setEfeitosColaterais(rs.getString("efeitos_colaterais"));
                 rem.setContraIndicacoes(rs.getString("contra_indicacoes"));
                 return rem;
             }else{
                 return null;
             }
        
        
        
        } catch (SQLException ex) {
            return null;
        }
    }
    

    public Vector MostraRemedio (String pesq) throws Exception{
        
            Vector tb = new Vector();
            st = conn.prepareStatement("SELECT *FROM remedio WHERE onde_age LIKE ?");
            st.setString(1, '%' +pesq+'%');
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Vector nl = new Vector();
                nl.add(rs.getInt("id_produto"));
                nl.add(rs.getString("produto"));
                nl.add(rs.getString("onde_age"));
                nl.add(rs.getString("posologia"));
                tb.add(nl);
            }
             return tb;
    }
    
    
}
