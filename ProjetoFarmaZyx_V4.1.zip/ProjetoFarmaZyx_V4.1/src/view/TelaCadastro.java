
package view;

import data.Usuario;
import data.UsuarioDao;
import javax.swing.JOptionPane;

public class TelaCadastro extends javax.swing.JFrame {

    public TelaCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblSenha = new javax.swing.JLabel();
        txtSenha = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblNome.setText("Nome Completo");
        getContentPane().add(lblNome);
        lblNome.setBounds(190, 140, 110, 16);
        getContentPane().add(txtNome);
        txtNome.setBounds(340, 140, 370, 30);

        lblCpf.setText("CPF");
        getContentPane().add(lblCpf);
        lblCpf.setBounds(190, 200, 37, 16);
        getContentPane().add(txtCpf);
        txtCpf.setBounds(340, 200, 370, 30);

        lblEmail.setText("E-Mail");
        getContentPane().add(lblEmail);
        lblEmail.setBounds(190, 260, 60, 20);
        getContentPane().add(txtEmail);
        txtEmail.setBounds(340, 260, 370, 30);

        lblSenha.setText("Senha");
        getContentPane().add(lblSenha);
        lblSenha.setBounds(190, 320, 50, 20);
        getContentPane().add(txtSenha);
        txtSenha.setBounds(340, 320, 370, 30);

        jButton1.setText("Salvar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(660, 410, 90, 30);

        jButton2.setText("Voltar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(840, 412, 80, 30);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Cadastro");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(450, 50, 100, 30);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        TelaLogin tela = new TelaLogin();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String senha = new String(txtSenha.getPassword()).trim();
        Usuario usuario = new Usuario();
        UsuarioDao dao;
        boolean status;
        int resp;
        
        usuario.setCpf(txtCpf.getText());
        usuario.setNome(txtNome.getText());
        usuario.setEmail(txtEmail.getText());
        usuario.setSenha(senha);
        
        dao = new UsuarioDao();
        status = dao.conectar();
        if(status==false){
            JOptionPane.showMessageDialog(null, "Erro na conexão com o Banco de Dados");
            limparCampos();
        } else {
            resp = dao.salvar(usuario);
            if(resp == 1){
                JOptionPane.showMessageDialog(null, "Dados Incluídos com sucesso");
            } else if(resp == 1062){
                JOptionPane.showMessageDialog(null, "Essa matrícula ja foi cadastrada");
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao tentar cadastrar o usuário");
            }
            dao.desconectar();
            limparCampos();
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }
    
    public void limparCampos(){
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtSenha.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNome;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
