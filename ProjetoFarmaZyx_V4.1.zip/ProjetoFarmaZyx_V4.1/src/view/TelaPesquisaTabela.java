package view;

import data.RemediosDao;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaPesquisaTabela extends javax.swing.JFrame {

    public TelaPesquisaTabela() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbRemedios = new javax.swing.JTable();
        txtPesquisa = new javax.swing.JTextField();
        lblSintoma = new javax.swing.JLabel();
        btnSaibamais = new javax.swing.JButton();
        btnComprar = new javax.swing.JButton();
        lblAchou = new javax.swing.JLabel();
        lblDecidiu = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        tbRemedios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Produto", "Onde age", "Posologia"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbRemedios);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 180, 900, 320);

        txtPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisaActionPerformed(evt);
            }
        });
        txtPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPesquisaKeyReleased(evt);
            }
        });
        getContentPane().add(txtPesquisa);
        txtPesquisa.setBounds(50, 110, 580, 30);

        lblSintoma.setText("O que você está sentindo ?");
        getContentPane().add(lblSintoma);
        lblSintoma.setBounds(50, 80, 180, 20);

        btnSaibamais.setText("Saiba mais");
        btnSaibamais.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaibamaisActionPerformed(evt);
            }
        });
        getContentPane().add(btnSaibamais);
        btnSaibamais.setBounds(850, 40, 100, 30);

        btnComprar.setText("Comprar");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });
        getContentPane().add(btnComprar);
        btnComprar.setBounds(850, 100, 100, 30);

        lblAchou.setText("Achou seu remédio?");
        getContentPane().add(lblAchou);
        lblAchou.setBounds(717, 40, 120, 20);

        lblDecidiu.setText("Está decidido?");
        getContentPane().add(lblDecidiu);
        lblDecidiu.setBounds(720, 100, 90, 20);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaActionPerformed

    private void txtPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPesquisaKeyReleased
       RemediosDao dao  = new RemediosDao();
       boolean status = dao.conectar();
       if(status == true){
            try{
            Vector cabecalho = new Vector();
            cabecalho.add("ID");
            cabecalho.add("Produto");
            cabecalho.add("Onde age");
            cabecalho.add("Posologia");
            if(!txtPesquisa.getText().equals("")){
                    DefaultTableModel nv = new DefaultTableModel(dao.MostraRemedio(txtPesquisa.getText()),cabecalho);
                    tbRemedios.setModel(nv);
            } else {
                    DefaultTableModel nv = new DefaultTableModel(new Vector(), cabecalho);
                    tbRemedios.setModel(nv);
            }
            } catch(Exception ex){
                JOptionPane.showMessageDialog(null, "Erro: " + ex.getMessage());
            }
       } else{
           JOptionPane.showMessageDialog(null, "Erro na coxeção com o banco");
       }
       
    }//GEN-LAST:event_txtPesquisaKeyReleased

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        TelaCompras tela = new TelaCompras();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnComprarActionPerformed

    private void btnSaibamaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaibamaisActionPerformed
        TelaPesquisa tela = new TelaPesquisa();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnSaibamaisActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisaTabela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisaTabela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisaTabela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisaTabela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPesquisaTabela().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnSaibamais;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAchou;
    private javax.swing.JLabel lblDecidiu;
    private javax.swing.JLabel lblSintoma;
    private javax.swing.JTable tbRemedios;
    private javax.swing.JTextField txtPesquisa;
    // End of variables declaration//GEN-END:variables
}
