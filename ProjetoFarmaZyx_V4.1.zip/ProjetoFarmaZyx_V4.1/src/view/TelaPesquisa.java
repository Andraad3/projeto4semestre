
package view;

import data.Remedios;
import data.RemediosDao;
import javax.swing.JOptionPane;


public class TelaPesquisa extends javax.swing.JFrame {

    public TelaPesquisa() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtPesquisar = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();
        lblCodigo = new javax.swing.JLabel();
        lblProduto = new javax.swing.JLabel();
        lblOndeage = new javax.swing.JLabel();
        lblComposicao = new javax.swing.JLabel();
        lblPosologia = new javax.swing.JLabel();
        lblEfeitosColaterais = new javax.swing.JLabel();
        lblContraIndicacao = new javax.swing.JLabel();
        btnComprar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtEfeitosColaterais = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtContraIndicacao = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtProduto = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtOndeage = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtComposicao = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtPosologia = new javax.swing.JTextArea();
        btnVoltar = new javax.swing.JButton();
        txtCodigo = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(txtPesquisar);
        txtPesquisar.setBounds(50, 30, 660, 30);

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });
        getContentPane().add(btnPesquisar);
        btnPesquisar.setBounds(730, 30, 120, 30);

        lblCodigo.setText("Código");
        getContentPane().add(lblCodigo);
        lblCodigo.setBounds(20, 110, 50, 20);

        lblProduto.setText("Produto");
        getContentPane().add(lblProduto);
        lblProduto.setBounds(20, 160, 50, 20);

        lblOndeage.setText("Onde age");
        getContentPane().add(lblOndeage);
        lblOndeage.setBounds(20, 210, 60, 20);

        lblComposicao.setText("Composição");
        getContentPane().add(lblComposicao);
        lblComposicao.setBounds(20, 310, 90, 20);

        lblPosologia.setText("Posologia");
        getContentPane().add(lblPosologia);
        lblPosologia.setBounds(20, 410, 60, 20);

        lblEfeitosColaterais.setText("Efeitos Colaterais");
        getContentPane().add(lblEfeitosColaterais);
        lblEfeitosColaterais.setBounds(530, 110, 100, 20);

        lblContraIndicacao.setText("Contra Indicações");
        getContentPane().add(lblContraIndicacao);
        lblContraIndicacao.setBounds(530, 270, 100, 30);

        btnComprar.setText("Comprar");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });
        getContentPane().add(btnComprar);
        btnComprar.setBounds(860, 460, 100, 30);

        txtEfeitosColaterais.setColumns(20);
        txtEfeitosColaterais.setRows(5);
        jScrollPane2.setViewportView(txtEfeitosColaterais);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(640, 110, 330, 140);

        txtContraIndicacao.setColumns(20);
        txtContraIndicacao.setRows(5);
        jScrollPane3.setViewportView(txtContraIndicacao);

        getContentPane().add(jScrollPane3);
        jScrollPane3.setBounds(640, 280, 330, 150);

        txtProduto.setColumns(20);
        txtProduto.setRows(5);
        jScrollPane4.setViewportView(txtProduto);

        getContentPane().add(jScrollPane4);
        jScrollPane4.setBounds(130, 156, 330, 40);

        txtOndeage.setColumns(20);
        txtOndeage.setRows(5);
        jScrollPane5.setViewportView(txtOndeage);

        getContentPane().add(jScrollPane5);
        jScrollPane5.setBounds(130, 220, 330, 70);

        txtComposicao.setColumns(20);
        txtComposicao.setRows(5);
        jScrollPane6.setViewportView(txtComposicao);

        getContentPane().add(jScrollPane6);
        jScrollPane6.setBounds(130, 310, 330, 70);

        txtPosologia.setColumns(20);
        txtPosologia.setRows(5);
        jScrollPane7.setViewportView(txtPosologia);

        getContentPane().add(jScrollPane7);
        jScrollPane7.setBounds(130, 400, 330, 70);

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoltar);
        btnVoltar.setBounds(880, 30, 90, 30);
        getContentPane().add(txtCodigo);
        txtCodigo.setBounds(130, 110, 60, 30);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
         String pesquisar;
         pesquisar = txtPesquisar.getText();
       
       RemediosDao dao  = new RemediosDao();
       boolean status = dao.conectar();
       if(status == true){
          Remedios remedio = dao.consultar(pesquisar);
          if(remedio  == null){
              JOptionPane.showMessageDialog(null, "Remédio não localizado");
          }else{
              txtCodigo.setText(remedio.getIdProduto());
              txtProduto.setText(remedio.getProduto());
              txtComposicao.setText(remedio.getComposicao());
              txtPosologia.setText(remedio.getPosologia());
              txtOndeage.setText(remedio.getOndeAge());
              txtEfeitosColaterais.setText(remedio.getEfeitosColaterais());
              txtContraIndicacao.setText(remedio.getContraIndicacoes());
          }
          dao.desconectar();
       }else{
           JOptionPane.showMessageDialog(null, "Erro na conexão com o bando de dados");
       }
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        TelaCompras tela = new TelaCompras();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnComprarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        TelaPesquisaTabela tela = new TelaPesquisaTabela();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPesquisa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblComposicao;
    private javax.swing.JLabel lblContraIndicacao;
    private javax.swing.JLabel lblEfeitosColaterais;
    private javax.swing.JLabel lblOndeage;
    private javax.swing.JLabel lblPosologia;
    private javax.swing.JLabel lblProduto;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextArea txtComposicao;
    private javax.swing.JTextArea txtContraIndicacao;
    private javax.swing.JTextArea txtEfeitosColaterais;
    private javax.swing.JTextArea txtOndeage;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JTextArea txtPosologia;
    private javax.swing.JTextArea txtProduto;
    // End of variables declaration//GEN-END:variables
}
