package view;

import data.Usuario;
import data.UsuarioDao;
import javax.swing.JOptionPane;

public class TelaLogin extends javax.swing.JFrame {

    public TelaLogin() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnAcessar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        lblUsuario = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtSenha = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        lblCadastro = new javax.swing.JLabel();
        lblTelaFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        btnAcessar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnAcessar.setText("Acessar");
        btnAcessar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAcessarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAcessar);
        btnAcessar.setBounds(410, 340, 100, 40);

        btnSair.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnSair.setText("Sair");
        getContentPane().add(btnSair);
        btnSair.setBounds(580, 340, 80, 40);

        lblUsuario.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblUsuario.setForeground(new java.awt.Color(0, 0, 0));
        lblUsuario.setText("E-mail");
        getContentPane().add(lblUsuario);
        lblUsuario.setBounds(280, 190, 60, 20);

        lblSenha.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblSenha.setForeground(new java.awt.Color(0, 0, 0));
        lblSenha.setText("Senha");
        getContentPane().add(lblSenha);
        lblSenha.setBounds(280, 250, 60, 20);
        getContentPane().add(txtEmail);
        txtEmail.setBounds(410, 190, 250, 30);
        getContentPane().add(txtSenha);
        txtSenha.setBounds(410, 250, 250, 30);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("FarmaZyx");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(430, 50, 110, 40);

        lblCadastro.setForeground(new java.awt.Color(0, 0, 0));
        lblCadastro.setText("Clique aqui para se Cadastrar");
        lblCadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCadastroMouseClicked(evt);
            }
        });
        getContentPane().add(lblCadastro);
        lblCadastro.setBounds(410, 290, 250, 16);

        lblTelaFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FotoFundo.jpg"))); // NOI18N
        getContentPane().add(lblTelaFundo);
        lblTelaFundo.setBounds(0, 0, 1000, 530);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAcessarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAcessarActionPerformed
        UsuarioDao dao = new UsuarioDao();
        boolean status = dao.conectar();
        if(status==true){
            Usuario usu = dao.logar(txtEmail.getText(), txtSenha.getText());
            
            if(usu==null){
                JOptionPane.showMessageDialog(null, "Email e/ou Senha Inválido");
            } else {
                JOptionPane.showMessageDialog(null, "Seja Bem Vindo "+ usu.getNome());
                TelaPesquisaTabela tela = new TelaPesquisaTabela();
                tela.setVisible(true);
                this.dispose();
            } 
            
        }else{
            JOptionPane.showMessageDialog(null, "Erro na conexão");
        }
       
        
       
    }//GEN-LAST:event_btnAcessarActionPerformed

    private void lblCadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCadastroMouseClicked
        TelaCadastro tela = new TelaCadastro();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblCadastroMouseClicked


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAcessar;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblCadastro;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JLabel lblTelaFundo;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
