
package view;

import data.Remedios;
import data.RemediosDao_TelaPesquisa;
import javax.swing.JOptionPane;


public class TelaPesquisa extends javax.swing.JFrame {

    public TelaPesquisa() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtPesquisar = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();
        lblCodigo = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        lblProduto = new javax.swing.JLabel();
        txtProduto = new javax.swing.JTextField();
        lblOndeage = new javax.swing.JLabel();
        txtOndeage = new javax.swing.JTextField();
        lblComposicao = new javax.swing.JLabel();
        txtComposicao = new javax.swing.JTextField();
        lblPosologia = new javax.swing.JLabel();
        txtPosologia = new javax.swing.JTextField();
        lblEfeitosColaterais = new javax.swing.JLabel();
        txtEfeitosColaterais = new javax.swing.JTextField();
        lblContraIndicacao = new javax.swing.JLabel();
        txtContraIndicacao = new javax.swing.JTextField();
        btnComprar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(txtPesquisar);
        txtPesquisar.setBounds(50, 30, 660, 30);

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });
        getContentPane().add(btnPesquisar);
        btnPesquisar.setBounds(730, 30, 120, 30);

        lblCodigo.setText("Código");
        getContentPane().add(lblCodigo);
        lblCodigo.setBounds(20, 110, 50, 20);
        getContentPane().add(txtCodigo);
        txtCodigo.setBounds(130, 110, 140, 30);

        lblProduto.setText("Produto");
        getContentPane().add(lblProduto);
        lblProduto.setBounds(20, 160, 50, 20);
        getContentPane().add(txtProduto);
        txtProduto.setBounds(130, 160, 330, 30);

        lblOndeage.setText("Onde age");
        getContentPane().add(lblOndeage);
        lblOndeage.setBounds(20, 210, 60, 20);
        getContentPane().add(txtOndeage);
        txtOndeage.setBounds(130, 210, 330, 80);

        lblComposicao.setText("Composição");
        getContentPane().add(lblComposicao);
        lblComposicao.setBounds(20, 330, 70, 20);
        getContentPane().add(txtComposicao);
        txtComposicao.setBounds(130, 330, 330, 70);

        lblPosologia.setText("Posologia");
        getContentPane().add(lblPosologia);
        lblPosologia.setBounds(20, 440, 60, 20);
        getContentPane().add(txtPosologia);
        txtPosologia.setBounds(130, 430, 330, 70);

        lblEfeitosColaterais.setText("Efeitos Colaterais");
        getContentPane().add(lblEfeitosColaterais);
        lblEfeitosColaterais.setBounds(530, 110, 100, 20);
        getContentPane().add(txtEfeitosColaterais);
        txtEfeitosColaterais.setBounds(640, 110, 330, 140);

        lblContraIndicacao.setText("Contra Indicações");
        getContentPane().add(lblContraIndicacao);
        lblContraIndicacao.setBounds(530, 290, 100, 30);
        getContentPane().add(txtContraIndicacao);
        txtContraIndicacao.setBounds(640, 300, 330, 180);

        btnComprar.setText("Comprar");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });
        getContentPane().add(btnComprar);
        btnComprar.setBounds(870, 30, 100, 30);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
         String pesquisar;
         pesquisar = txtPesquisar.getText();
       
       RemediosDao_TelaPesquisa dao  = new RemediosDao_TelaPesquisa();
       boolean status = dao.conectar();
       if(status == true){
          Remedios remedio = dao.consultar(pesquisar);
          if(remedio  == null){
              JOptionPane.showMessageDialog(null, "Remédio não localizado");
          }else{
              txtCodigo.setText(remedio.getIdProduto());
              txtProduto.setText(remedio.getProduto());
              txtComposicao.setText(remedio.getComposicao());
              txtPosologia.setText(remedio.getPosologia());
              txtOndeage.setText(remedio.getOndeAge());
              txtEfeitosColaterais.setText(remedio.getEfeitosColaterais());
              txtContraIndicacao.setText(remedio.getContraIndicacoes());
          }
          dao.desconectar();
       }else{
           JOptionPane.showMessageDialog(null, "Erro na conexão com o bando de dados");
       }
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        TelaCompras tela = new TelaCompras();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnComprarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPesquisa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPesquisa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblComposicao;
    private javax.swing.JLabel lblContraIndicacao;
    private javax.swing.JLabel lblEfeitosColaterais;
    private javax.swing.JLabel lblOndeage;
    private javax.swing.JLabel lblPosologia;
    private javax.swing.JLabel lblProduto;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtComposicao;
    private javax.swing.JTextField txtContraIndicacao;
    private javax.swing.JTextField txtEfeitosColaterais;
    private javax.swing.JTextField txtOndeage;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JTextField txtPosologia;
    private javax.swing.JTextField txtProduto;
    // End of variables declaration//GEN-END:variables
}
