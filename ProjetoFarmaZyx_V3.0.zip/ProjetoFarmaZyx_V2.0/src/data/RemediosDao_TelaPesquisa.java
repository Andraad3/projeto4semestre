package data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RemediosDao_TelaPesquisa {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/remedio","root","");
            
            
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            return false;
        }
    }
    
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    /*public int salvar(Remedios remedio){
       int status;
        
        try {  
            
            st = conn.prepareStatement("INSERT INTO funcionario VALUES(?,?,?,?,?,?,?)");
            conn.setString(1, remedio.getIdProduto());
            conn.setString(2, remedio.getProduto());
            conn.setString(3, remedio.getComposicao());
            conn.setString(4, remedio.getPosologia());
            conn.setString(5, remedio.getOndeAge());
            conn.setString(6, remedio.getEfeitosColaterais());
            conn.setString(7, remedio.getContraIndicacoes());
            
            status = st.executeUpdate();
            return status;//retorna 1
        }catch(SQLException ex){    
            //System.out.println(ex.getErrorCode());
            return ex.getErrorCode();
            //1062 pk ja cadastrada
        }
    }
    
    */
    
    public Remedios consultar(String pesquisar){
        Remedios rem = new Remedios();
        try {
            st = conn.prepareStatement("SELECT *FROM remedio WHERE produto LIKE ?");
            st.setString(1, '%' +pesquisar+'%');
            ResultSet rs = st.executeQuery();
             if(rs.next()){
                 rem.setIdProduto(rs.getString("id_produto"));
                 rem.setProduto(rs.getString("produto"));
                 rem.setComposicao(rs.getString("composicao"));
                 rem.setPosologia(rs.getString("posologia"));
                 rem.setOndeAge(rs.getString("onde_age"));
                 rem.setEfeitosColaterais(rs.getString("efeitos_colaterais"));
                 rem.setContraIndicacoes(rs.getString("contra_indicacoes"));
                 return rem;
             }else{
                 return null;
             }
        
        
        
        } catch (SQLException ex) {
            return null;
        }
    
    }
    
    
}
