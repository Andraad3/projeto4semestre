package data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class RemediosDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;
    
    //Método Conectar, com ele a conexão com o banco é estabelecida
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/remedio","root","");
            
            
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            return false;
        }
    }
    
    //Método Desconectar, com ele a conexão com o banco termina
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    
    //Método Consultar, para mostrar informações de 1 remédio específico.
    public Remedios consultar(String pesquisar){
        Remedios rem = new Remedios();
        try {
            st = conn.prepareStatement("SELECT *FROM remedio WHERE produto LIKE ?");
            st.setString(1, '%' +pesquisar+'%');
            ResultSet rs = st.executeQuery();
             if(rs.next()){
                 rem.setIdProduto(rs.getString("id_produto"));
                 rem.setProduto(rs.getString("produto"));
                 rem.setComposicao(rs.getString("composicao"));
                 rem.setPosologia(rs.getString("posologia"));
                 rem.setOndeAge(rs.getString("onde_age"));
                 rem.setEfeitosColaterais(rs.getString("efeitos_colaterais"));
                 rem.setContraIndicacoes(rs.getString("contra_indicacoes"));
                 return rem;
             }else{
                 return null;
             }
        
        
        
        } catch (SQLException ex) {
            return null;
        }
    }
    
    //Metodo de consulta para mostrar remédios na lista.
    public Vector MostraRemedio (String pesq) throws Exception{
        
            Vector tb = new Vector();
            st = conn.prepareStatement("SELECT *FROM remedio WHERE onde_age LIKE ?");
            st.setString(1, '%' +pesq+'%');
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Vector nl = new Vector();
                nl.add(rs.getInt("id_produto"));
                nl.add(rs.getString("produto"));
                nl.add(rs.getString("onde_age"));
                nl.add(rs.getString("posologia"));
                tb.add(nl);
            }
             return tb;
    }
    
    
}
