
package data;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class UsuarioDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public UsuarioDao() {
    }
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/remedio","root","");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            return false;
        }
    }
    
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    
    //Salva Cadastro de Login do Usuário no banco
    public int salvar(Usuario usuario){
        int status;
        try {
            st = conn.prepareStatement("INSERT INTO usuario VALUES(?,?,?,?)");
            st.setString(2, usuario.getCpf());
            st.setString(1, usuario.getNome());
            st.setString(3, usuario.getEmail());
            st.setString(4, usuario.getSenha());
            status = st.executeUpdate();
            return status;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode());
            return ex.getErrorCode();
            //1062 - Se inserir matrícula ja cadastrada;
        }
    }
   
    //Verifica se dados são compativeis no banco e permite login
    public Usuario logar(String email, String senha){
        
        try {
            String sql = "SELECT nome FROM usuario WHERE email=? AND senha=?";
            st = conn.prepareStatement(sql);
            st.setString(1,email);
            st.setString(2,senha);
            rs = st.executeQuery();
            if(rs.next()){
                Usuario usu = new Usuario();
                usu.setNome(rs.getString("nome"));
                return usu;
            } else{
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            return null;
        }
        
    }
    
}
