
package view;

import data.Usuario;
import data.UsuarioDao;
import javax.swing.JOptionPane;

public class TelaCadastro extends javax.swing.JFrame {

    public TelaCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblSenha = new javax.swing.JLabel();
        txtSenha = new javax.swing.JPasswordField();
        btnSalvar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        lblCadastro = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro FarmaZyx");
        getContentPane().setLayout(null);

        lblNome.setText("Nome Completo");
        getContentPane().add(lblNome);
        lblNome.setBounds(190, 140, 110, 16);
        getContentPane().add(txtNome);
        txtNome.setBounds(340, 140, 370, 30);

        lblCpf.setText("CPF");
        getContentPane().add(lblCpf);
        lblCpf.setBounds(190, 200, 37, 16);
        getContentPane().add(txtCpf);
        txtCpf.setBounds(340, 200, 370, 30);

        lblEmail.setText("E-Mail");
        getContentPane().add(lblEmail);
        lblEmail.setBounds(190, 260, 60, 20);
        getContentPane().add(txtEmail);
        txtEmail.setBounds(340, 260, 370, 30);

        lblSenha.setText("Senha");
        getContentPane().add(lblSenha);
        lblSenha.setBounds(190, 320, 50, 20);
        getContentPane().add(txtSenha);
        txtSenha.setBounds(340, 320, 370, 30);

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalvar);
        btnSalvar.setBounds(660, 410, 90, 30);

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoltar);
        btnVoltar.setBounds(840, 412, 80, 30);

        lblCadastro.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblCadastro.setText("Cadastro");
        getContentPane().add(lblCadastro);
        lblCadastro.setBounds(450, 50, 100, 30);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    //Botão de voltar
    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        TelaLogin tela = new TelaLogin();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    //Botão de salvar dados no banco
    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        String senha = new String(txtSenha.getPassword()).trim();
        Usuario usuario = new Usuario();
        UsuarioDao dao;
        boolean status;
        int resp;
        
        usuario.setCpf(txtCpf.getText());
        usuario.setNome(txtNome.getText());
        usuario.setEmail(txtEmail.getText());
        usuario.setSenha(senha);
        
        dao = new UsuarioDao();
        status = dao.conectar();
        if(status==false){
            JOptionPane.showMessageDialog(null, "Erro na conexão com o Banco de Dados");
            limparCampos();
        } else {
            resp = dao.salvar(usuario);
            if(resp == 1){
                JOptionPane.showMessageDialog(null, "Dados Incluídos com sucesso");
            } else if(resp == 1062){
                JOptionPane.showMessageDialog(null, "Essa matrícula ja foi cadastrada");
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao tentar cadastrar o usuário");
            }
            dao.desconectar();
            limparCampos();
        }
        
    }//GEN-LAST:event_btnSalvarActionPerformed

    
    //Método que limpa os campos preenchidos
    public void limparCampos(){
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtSenha.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lblCadastro;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNome;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
