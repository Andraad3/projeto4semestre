
package view;

public class TelaCompras extends javax.swing.JFrame {

    public TelaCompras() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnDrogaSil = new javax.swing.JButton();
        btnUltraFarma = new javax.swing.JButton();
        btnDrogaSP = new javax.swing.JButton();
        btnDrogaRaia = new javax.swing.JButton();
        lblImgDrogasil = new javax.swing.JLabel();
        lblImgRaia = new javax.swing.JLabel();
        lblImgUltra = new javax.swing.JLabel();
        lblImgDSP = new javax.swing.JLabel();
        txtOndeComprar = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Compras FarmaZyx");
        getContentPane().setLayout(null);

        btnDrogaSil.setText("Drogasil");
        btnDrogaSil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDrogaSilActionPerformed(evt);
            }
        });
        getContentPane().add(btnDrogaSil);
        btnDrogaSil.setBounds(520, 440, 170, 50);

        btnUltraFarma.setText("UltraFarma");
        btnUltraFarma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUltraFarmaActionPerformed(evt);
            }
        });
        getContentPane().add(btnUltraFarma);
        btnUltraFarma.setBounds(280, 440, 160, 50);

        btnDrogaSP.setText("Drogaria São Paulo");
        btnDrogaSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDrogaSPActionPerformed(evt);
            }
        });
        getContentPane().add(btnDrogaSP);
        btnDrogaSP.setBounds(760, 440, 180, 50);

        btnDrogaRaia.setText("Droga Raia");
        btnDrogaRaia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDrogaRaiaActionPerformed(evt);
            }
        });
        getContentPane().add(btnDrogaRaia);
        btnDrogaRaia.setBounds(60, 440, 140, 50);

        lblImgDrogasil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Drogasil.png"))); // NOI18N
        lblImgDrogasil.setText("jLabel1");
        getContentPane().add(lblImgDrogasil);
        lblImgDrogasil.setBounds(500, 230, 210, 190);

        lblImgRaia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logo-raia.jpg"))); // NOI18N
        lblImgRaia.setText("jLabel3");
        getContentPane().add(lblImgRaia);
        lblImgRaia.setBounds(30, 230, 190, 190);

        lblImgUltra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ultrafarma.png"))); // NOI18N
        lblImgUltra.setText("jLabel2");
        getContentPane().add(lblImgUltra);
        lblImgUltra.setBounds(260, 230, 200, 190);

        lblImgDSP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logo_DrogariaSp.jpg"))); // NOI18N
        lblImgDSP.setText("jLabel4");
        getContentPane().add(lblImgDSP);
        lblImgDSP.setBounds(750, 230, 200, 190);

        txtOndeComprar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtOndeComprar.setText("Onde Comprar");
        getContentPane().add(txtOndeComprar);
        txtOndeComprar.setBounds(380, 70, 240, 50);

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoltar);
        btnVoltar.setBounds(60, 40, 72, 22);

        setSize(new java.awt.Dimension(1014, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    //Botões que redirecionam para o site da farmácia
    private void btnDrogaSilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDrogaSilActionPerformed

        try{
            java.awt.Desktop.getDesktop().browse( new java.net.URI("http://www.drogasil.com.br"));
        }catch(Exception erro){
            System.out.println(erro);
        }
    }//GEN-LAST:event_btnDrogaSilActionPerformed

    private void btnUltraFarmaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUltraFarmaActionPerformed
         try{
            java.awt.Desktop.getDesktop().browse( new java.net.URI("http://www.ultrafarma.com.br"));
        }catch(Exception erro){
            System.out.println(erro);
        }
    }//GEN-LAST:event_btnUltraFarmaActionPerformed

    private void btnDrogaSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDrogaSPActionPerformed
         try{
            java.awt.Desktop.getDesktop().browse( new java.net.URI("http://www.drogariasaopaulo.com.br"));
        }catch(Exception erro){
            System.out.println(erro);
        }
    }//GEN-LAST:event_btnDrogaSPActionPerformed

    private void btnDrogaRaiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDrogaRaiaActionPerformed
         try{
            java.awt.Desktop.getDesktop().browse( new java.net.URI("http://www.drogaraia.com.br"));
        }catch(Exception erro){
            System.out.println(erro);
        }
    }//GEN-LAST:event_btnDrogaRaiaActionPerformed

    //botão voltar
    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        TelaPesquisa tela = new TelaPesquisa();
        tela.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDrogaRaia;
    private javax.swing.JButton btnDrogaSP;
    private javax.swing.JButton btnDrogaSil;
    private javax.swing.JButton btnUltraFarma;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lblImgDSP;
    private javax.swing.JLabel lblImgDrogasil;
    private javax.swing.JLabel lblImgRaia;
    private javax.swing.JLabel lblImgUltra;
    private javax.swing.JLabel txtOndeComprar;
    // End of variables declaration//GEN-END:variables
}
