
package data;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FarmaceuticoDao {
    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public FarmaceuticoDao() {
    }
    
    public boolean conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/remedio","root","");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            return false;
        }
    }
    
    public int salvar(Farmaceutico farmaceutico){
        int status;
        try {
            st = conn.prepareStatement("INSERT INTO farmaceutico VALUES(?,?,?,?,?)");
            st.setString(1, farmaceutico.getNome());
            st.setString(2, farmaceutico.getCpf());
            st.setString(3, farmaceutico.getCrf());
            st.setString(4, farmaceutico.getTelefone());
            st.setString(5, farmaceutico.getEmail());
            status = st.executeUpdate();
            return status;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode());
            return ex.getErrorCode();
            //1062 - Se inserir matrícula ja cadastrada;
        }
    }
    
    public void desconectar(){
        try {
            conn.close();
        } catch (SQLException ex) {
            
        }
    }
    
    public Farmaceutico consultar(String crf){
        try {
            Farmaceutico farmaceutico = new Farmaceutico();
            st = conn.prepareStatement("SELECT * FROM farmaceutico WHERE crf = ?");
            st.setString(1, crf);
            rs = st.executeQuery();
            //Verifica se consulta encontrou o funcionário com a matrícula informada
            if(rs.next()){ //Se encontrou funcionário
                farmaceutico.setNome(rs.getString("nome"));
                farmaceutico.setCpf(rs.getString("cpf"));
                farmaceutico.setCrf(rs.getString("crf"));
                farmaceutico.setTelefone(rs.getString("telefone"));
                farmaceutico.setEmail(rs.getString("email"));
                return farmaceutico;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null;
        }
    }
    
    public boolean excluir  (String crf){
        try {
            st = conn.prepareStatement("DELETE FROM farmaceutico WHERE crf = ?");
            st.setString(1, crf);
            st.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
}
