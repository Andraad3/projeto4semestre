package data;

public class Remedios {
    private String idProduto;
    private String produto;
    private String composicao;
    private String posologia;
    private String ondeAge;
    private String efeitosColaterais;
    private String contraIndicacoes;

    public Remedios() {
    }
    //métodos getter e setter
    
    public String getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(String idProduto) {
        this.idProduto = idProduto;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public String getComposicao() {
        return composicao;
    }

    public void setComposicao(String composicao) {
        this.composicao = composicao;
    }

    public String getPosologia() {
        return posologia;
    }

    public void setPosologia(String posologia) {
        this.posologia = posologia;
    }

    public String getOndeAge() {
        return ondeAge;
    }

    public void setOndeAge(String ondeAge) {
        this.ondeAge = ondeAge;
    }

    public String getEfeitosColaterais() {
        return efeitosColaterais;
    }

    public void setEfeitosColaterais(String efeitosColaterais) {
        this.efeitosColaterais = efeitosColaterais;
    }

    public String getContraIndicacoes() {
        return contraIndicacoes;
    }

    public void setContraIndicacoes(String contraIndicacoes) {
        this.contraIndicacoes = contraIndicacoes;
    }
    
    

    






}

